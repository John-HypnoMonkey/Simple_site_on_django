class room():
    def __init__(self,x,y,w,h,room_type="standart"):
        self.x, self.y, self.w, self.h = x, y, w, h
        self.room_type = room_type
