# HypnoRoguelike is a simple roguelike on python
In order to start the game, type into your shell:
python3 game.py

Use WASD for moving.
Q to exit.
"g" are your enemies
"," are heal potions
"$" are money
